-- 9.	Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.

SELECT 
    g.name AS genre_name,
    ROUND(SUM(il.unit_price * il.quantity), 2) AS genre_sales,
    ROUND(SUM(il.unit_price * il.quantity) / (
        SELECT SUM(il2.unit_price * il2.quantity)
        FROM invoice i2
        JOIN invoice_line il2 ON i2.invoice_id = il2.invoice_id
        WHERE i2.billing_country = 'USA'
    ) * 100, 2) AS percentage_of_total_sales
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE i.billing_country = 'USA'
GROUP BY g.genre_id, g.name
ORDER BY genre_sales DESC;

-- TOP GENRES AND ARTISTS 
SELECT 
    g.name AS genre_name,
    A.name AS artist_name,
    ROUND(SUM(il.unit_price * il.quantity), 2) AS genre_sales
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN album al ON t.album_id = al.album_id
JOIN artist A ON A.artist_id = al.artist_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE i.billing_country = 'USA'
GROUP BY g.genre_id, g.name, A.artist_id, A.name
ORDER BY genre_sales DESC
LIMIT 5;

