-- 11.	Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. 
-- They want to know the average total amount spent by customers from each country, along with the number of customers 
-- and the average number of tracks purchased per customer. Write an SQL query to provide this information.

WITH customer_totals AS (
    SELECT
        c.customer_id,
        c.country,
        SUM(i.total) AS total_spent,
        COUNT(il.invoice_line_id) AS total_tracks
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    GROUP BY c.customer_id, c.country
)

SELECT
    country,
    COUNT(customer_id) AS number_of_customers,
    ROUND(AVG(total_spent), 2) AS avg_spent_per_customer,
    ROUND(AVG(total_tracks), 2) AS avg_tracks_per_customer
FROM customer_totals
GROUP BY country
ORDER BY avg_spent_per_customer DESC;
