-- 6.	Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), which customer segments are more
-- likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

WITH max_invoice_date AS (
    SELECT MAX(invoice_date) AS max_date FROM invoice
),
customer_summary AS (
    SELECT
        c.customer_id,
        c.first_name,
        c.last_name,
        c.country,
        COALESCE(c.state, 'NA') AS state,
        c.city,
        MAX(i.invoice_date) AS last_purchase_date,
        COUNT(i.invoice_id) AS total_orders,
        SUM(i.total) AS total_spent,
        AVG(i.total) AS avg_order_value
    FROM customer c
    LEFT JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id, c.first_name, c.last_name, c.country, c.state, c.city
),
customer_risk_profile AS (
    SELECT
        cs.*,
        CASE
            WHEN cs.last_purchase_date < DATE_SUB(m.max_date, INTERVAL 12 MONTH) THEN 'High Risk'
            WHEN cs.total_orders <= 2 AND cs.total_spent < 50 THEN 'Medium Risk'
            ELSE 'Low Risk'
        END AS churn_risk
    FROM customer_summary cs
    CROSS JOIN max_invoice_date m
)
SELECT
    customer_id,
    first_name,
    last_name,
    country,
    state,
    city,
    last_purchase_date,
    total_orders,
    total_spent,
    avg_order_value,
    churn_risk
FROM customer_risk_profile
where churn_risk="High Risk"
ORDER BY churn_risk DESC, total_spent ASC;
