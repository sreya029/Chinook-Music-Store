-- 12.	Identify customers who have not made a purchase in the last 3 months

SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    MAX(i.invoice_date) AS last_purchase_date
FROM customer c
LEFT JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
HAVING last_purchase_date < DATE_SUB(
    (SELECT MAX(invoice_date) FROM invoice), INTERVAL 3 MONTH
);
