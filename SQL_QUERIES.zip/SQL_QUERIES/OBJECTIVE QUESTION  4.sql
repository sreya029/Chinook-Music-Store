/* 4.	Calculate the total revenue and number of invoices for each country, state, and city: */

SELECT billing_country as COUNTRY ,
	billing_state AS STATE,billing_city AS CITY,
    SUM(unit_price*quantity) AS TOTAL_REVENUE,
    COUNT(*) AS TOTAL_INVOICES
FROM invoice I
JOIN invoice_line IL ON I.invoice_id=IL.invoice_id
group by billing_country,billing_state,billing_city
ORDER BY TOTAL_REVENUE DESC,TOTAL_INVOICES DESC;