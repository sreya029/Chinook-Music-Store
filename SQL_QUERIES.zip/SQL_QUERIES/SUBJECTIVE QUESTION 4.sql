-- 4.	Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers? 
-- How can this information guide product recommendations and cross-selling initiatives?

WITH invoice_genres AS (
    SELECT
        i.invoice_id,
        g.name AS genre
    FROM
        invoice i
        JOIN invoice_line il ON i.invoice_id = il.invoice_id
        JOIN track t ON il.track_id = t.track_id
        JOIN genre g ON t.genre_id = g.genre_id
),

genre_pairs AS (
    SELECT
        a.genre AS genre_1,
        b.genre AS genre_2,
        COUNT(*) AS times_purchased_together
    FROM
        invoice_genres a
        JOIN invoice_genres b 
            ON a.invoice_id = b.invoice_id AND a.genre < b.genre
    GROUP BY
        a.genre, b.genre
    ORDER BY
        times_purchased_together DESC
)

SELECT * FROM genre_pairs LIMIT 10;
