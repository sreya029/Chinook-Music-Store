/* 3.	Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term customers
 differ from those of new customers? What insights can these patterns provide about customer loyalty and retention strategies? */

WITH max_invoice_date AS (
    SELECT MAX(invoice_date) AS max_date FROM invoice
),
customer_first_purchase AS (
    SELECT
        c.customer_id,
        MIN(i.invoice_date) AS first_purchase_date
    FROM
        customer c
        JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY
        c.customer_id
),
customer_purchasing_behavior AS (
    SELECT
        c.customer_id,
        CASE 
            WHEN f.first_purchase_date <= DATE_SUB(m.max_date, INTERVAL 3 YEAR ) THEN 'Long-Term'
            ELSE 'New'
        END AS customer_type,
        COUNT(DISTINCT i.invoice_id) AS purchase_frequency,
        COUNT(il.invoice_line_id) * 1.0 / COUNT(DISTINCT i.invoice_id) AS avg_basket_size,
        SUM(il.unit_price * il.quantity) AS total_revenue,
        SUM(il.unit_price * il.quantity) / COUNT(DISTINCT i.invoice_id) AS avg_order_value
    FROM
        customer c
        JOIN customer_first_purchase f ON c.customer_id = f.customer_id
        JOIN invoice i ON c.customer_id = i.customer_id
        JOIN invoice_line il ON i.invoice_id = il.invoice_id
        CROSS JOIN max_invoice_date m
    GROUP BY
        c.customer_id, f.first_purchase_date, m.max_date
)

SELECT
    customer_type,
    COUNT(*) AS total_customers,
    ROUND(AVG(purchase_frequency), 2) AS avg_purchase_frequency,
    ROUND(AVG(avg_basket_size), 2) AS avg_basket_size,
    ROUND(AVG(total_revenue), 2) AS avg_total_revenue,
    ROUND(AVG(avg_order_value), 2) AS avg_order_value
FROM
    customer_purchasing_behavior
GROUP BY
    customer_type;
