-- 5.	Find the top 5 customers by total revenue in each country

WITH CTE AS(SELECT C.country,
	CONCAT(C.FIRST_NAME," ",C.LAST_NAME) AS NAME,
	SUM(IL.unit_price*IL.quantity) AS TOTAL_REVENUE,
    DENSE_RANK() OVER (PARTITION BY COUNTRY ORDER BY SUM(IL.unit_price*IL.quantity) DESC) AS RANKS
FROM CUSTOMER C 
JOIN invoice I ON I.customer_id=C.customer_id
JOIN invoice_line IL ON I.invoice_id=IL.invoice_id
group by C.country,C.customer_id
)
SELECT COUNTRY,NAME,TOTAL_REVENUE,RANKS FROM CTE
WHERE RANKS<=5;