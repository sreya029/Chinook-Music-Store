-- 7.	Are there any patterns or trends in customer purchasing behavior (e.g., frequency of purchases, preferred payment methods, average order value)?
 
 SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    COUNT(i.invoice_id) AS order_count,
    ROUND(SUM(i.total) / COUNT(i.invoice_id), 2) AS avg_order_value
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id
HAVING COUNT(i.invoice_id)>(
    SELECT INVO.COUNT / CUST.COUNT AS AVGCUSTORDERVALUE
    FROM (SELECT COUNT(*) AS COUNT FROM CUSTOMER ) CUST,(SELECT COUNT(*) AS COUNT FROM INVOICE) INVO) OR 
    ROUND(SUM(i.total) / COUNT(i.invoice_id), 2)>(SELECT AVG(TOTAL) FROM invoice)
    ;
    