-- 7.	Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement) to predict the lifetime value of different customer segments? 
-- This could inform targeted marketing and loyalty program strategies. 
-- Can you observe any common characteristics or purchase patterns among customers who have stopped purchasing?

WITH customer_lifetime_summary AS (
    SELECT
        c.customer_id,
        MIN(i.invoice_date) AS first_purchase_date,
        MAX(i.invoice_date) AS last_purchase_date,
        DATEDIFF(MAX(i.invoice_date), MIN(i.invoice_date)) AS tenure_days,
        COUNT(i.invoice_id) AS frequency,
        SUM(i.total) AS total_spent,
        AVG(i.total) AS avg_order_value
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id
),
clv_score AS (
    SELECT
        *,
        ROUND(total_spent, 2) AS historical_clv,
        CASE
            WHEN total_spent > 100 THEN 'High CLV'
            WHEN total_spent BETWEEN 50 AND 100 THEN 'Medium CLV'
            ELSE 'Low CLV'
        END AS clv_segment
    FROM customer_lifetime_summary
)
SELECT * FROM clv_score
ORDER BY historical_clv DESC;
