-- 1.	Recommend the three albums from the new record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis.

SELECT 
    a.album_id,
    a.title,
    g.name AS genre,
    ROUND(SUM(il.unit_price * il.quantity), 2) AS total_sales
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN album a ON t.album_id = a.album_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE i.billing_country = 'USA'
GROUP BY a.album_id, a.title, g.name
ORDER BY total_sales DESC
LIMIT 3;