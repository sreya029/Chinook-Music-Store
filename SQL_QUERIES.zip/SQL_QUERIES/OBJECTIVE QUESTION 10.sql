-- 10.	Find customers who have purchased tracks from at least 3 different genres

SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    COUNT(DISTINCT t.genre_id) AS genre_count
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
GROUP BY c.customer_id, c.first_name, c.last_name
HAVING genre_count >= 3;
