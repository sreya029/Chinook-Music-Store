-- 10.	How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?

ALTER TABLE album
ADD COLUMN ReleaseYear INTEGER;

SET SQL_SAFE_UPDATES = 1;

UPDATE album 
SET ReleaseYear=2016 ;