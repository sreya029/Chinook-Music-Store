/* 2.	Find the top-selling tracks and top artist in the USA and identify their most famous genres. */

/*TOP SELLING TRACKS*/

SELECT T.TRACK_ID,T.NAME,SUM(IL.UNIT_PRICE*IL.QUANTITY) AS TOTALSALES
FROM TRACK T 
JOIN INVOICE_LINE IL ON IL.TRACK_ID=T.TRACK_ID
JOIN INVOICE I ON I.INVOICE_ID=IL.INVOICE_ID
WHERE I.BILLING_COUNTRY="USA" 
GROUP BY T.TRACK_ID,T.NAME
ORDER BY TOTALSALES DESC
LIMIT 3;

/* TOP ARTISTS */

SELECT A.ARTIST_ID,A.NAME,SUM(IL.UNIT_PRICE*IL.QUANTITY) AS TOTALSALES
FROM ARTIST A 
JOIN ALBUM AL ON AL.ARTIST_ID=A.ARTIST_ID
JOIN TRACK T ON T.ALBUM_ID=AL.ALBUM_ID
JOIN INVOICE_LINE IL ON IL.TRACK_ID=T.TRACK_ID
JOIN INVOICE I ON I.INVOICE_ID=IL.INVOICE_ID
WHERE I.BILLING_COUNTRY="USA" 
GROUP BY A.ARTIST_ID,A.NAME
ORDER BY TOTALSALES DESC
LIMIT 1;

/* TOP1 MOST FAMOUS GENRE */
SELECT 
    g.genre_id,
    g.name AS genre_name,
	AR.ARTIST_ID,
    AR.NAME,
    SUM(il.unit_price * il.quantity) AS genre_sales
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN album al ON t.album_id = al.album_id
JOIN artist ar ON al.artist_id = ar.artist_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE i.billing_country = 'USA' AND ar.artist_id = 152 -- 152 is the top artist id
GROUP BY g.genre_id, g.name
ORDER BY genre_sales DESC
LIMIT 1;
