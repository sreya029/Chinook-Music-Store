-- 5.	Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions or store locations? How might these correlate with local demographic or economic factors?

-- REGINAL PURCHASING BEHAVIOR
WITH customer_purchase_summary AS (
    SELECT
        i.customer_id,
        COUNT(i.invoice_id) AS total_purchase_frequency,
        SUM(i.total) AS total_spending,
        AVG(i.total) AS avg_order_value
    FROM invoice i
    GROUP BY i.customer_id
),
customer_location_summary AS (
    SELECT
        c.customer_id,
        c.country,
        COALESCE(c.state, 'Not Available') AS state,
        c.city,
        cps.total_purchase_frequency,
        cps.total_spending,
        cps.avg_order_value
    FROM customer c
    JOIN customer_purchase_summary cps ON c.customer_id = cps.customer_id
)
SELECT
    country,
    state,
    city,
    COUNT(DISTINCT customer_id) AS total_customers,
    SUM(total_purchase_frequency) AS total_purchases,
    ROUND(SUM(total_spending), 2) AS total_spending,
    ROUND(AVG(avg_order_value), 2) AS avg_order_value,
    ROUND(SUM(total_spending) / COUNT(DISTINCT customer_id), 2) AS avg_spending_per_customer
FROM customer_location_summary
GROUP BY country, state, city
ORDER BY total_spending DESC;

-- CHURN RATE BY REGION 
WITH latest_purchase_by_region AS (
    SELECT
        c.customer_id,
        c.country,
        COALESCE(c.state, 'NA') AS state,
        c.city,
        MAX(i.invoice_date) AS latest_purchase_date
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id, c.country, state, c.city
),
churned_customers_by_region AS (
    SELECT
        country,
        state,
        city,
        COUNT(customer_id) AS churned_customers
    FROM latest_purchase_by_region
    WHERE latest_purchase_date < DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
    GROUP BY country, state, city
)
SELECT
    cc.country,
    cc.state,
    cc.city,
    cc.churned_customers,
    COUNT(c.customer_id) AS total_customers,
    ROUND(cc.churned_customers * 100.0 / COUNT(c.customer_id), 2) AS churn_rate
FROM churned_customers_by_region cc
JOIN customer c 
    ON c.country = cc.country 
    AND COALESCE(c.state, 'NA') = cc.state 
    AND c.city = cc.city
GROUP BY cc.country, cc.state, cc.city, cc.churned_customers
ORDER BY churn_rate DESC;
