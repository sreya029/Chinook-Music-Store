-- 2.	Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.

SELECT 
    g.name AS genre_name,
    ROUND(SUM(il.unit_price * il.quantity), 2) AS total_sales
FROM invoice i
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE i.billing_country != 'USA'
GROUP BY g.genre_id, g.name
ORDER BY total_sales desc;