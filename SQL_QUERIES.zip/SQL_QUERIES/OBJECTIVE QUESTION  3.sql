/* 3.	What is the customer demographic breakdown (age, gender, location) of Chinook's customer base? */

SELECT COUNTRY,COUNT(*) AS Countrycount FROM CUSTOMER
GROUP BY COUNTRY
ORDER BY Countrycount desc;
