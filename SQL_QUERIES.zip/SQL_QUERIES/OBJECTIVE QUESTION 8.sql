-- 8. What is the customer churn rate?

-- LATEST PURCHASE 
SELECT MAX(INVOICE_DATE) FROM INVOICE;

-- TAKEN LAST 6 MONTHS 
SELECT 
    ROUND((churned.count * 1.0 / total.count) * 100,2) AS churn_rate_percent
FROM
    (SELECT COUNT(*) AS count FROM customer 
     WHERE customer_id NOT IN (
         SELECT DISTINCT customer_id
         FROM invoice
         WHERE invoice_date >= '2020-06-01' -- 6-MONTH BEFORE OF MAX INVOICE DATE 
    )) AS churned,
    (SELECT COUNT(*) AS count FROM customer) AS total;
